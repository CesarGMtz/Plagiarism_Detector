# Este es un archivo Python de ejemplo (por ejemplo, para 7LOCO.py)

def sumar_dos_numeros(num1, num2):
  """
  Esta función toma dos números como entrada y devuelve su suma.
  """
  resultado = num1 + num2
  return resultado

# Ejemplo de uso de la función
numero_a = 10
numero_b = 25

suma_total = sumar_dos_numeros(numero_a, numero_b)

print(f"La suma de {numero_a} y {numero_b} es: {suma_total}")

# Puedes probar con otros números
# print(f"La suma de 5 y 3 es: {sumar_dos_numeros(5, 3)}")