import pandas

c = 10

#Comment 1

def add(a, b):
    return a + b

    #comentario innecesario