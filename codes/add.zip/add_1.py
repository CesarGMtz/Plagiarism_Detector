import pandas

c = 10

#puto el que lo lea

def add(a, b):
    return a + b

    #comentario innecesario