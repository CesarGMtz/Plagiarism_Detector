def add(a, b):
    result = a + b
    if a > b:
        return result
    else:
        return b - a

def loop_example(x):
    total = 0
    for i in range(x):
        total += i
    while total < 100:
        total += 1
    return total

y = add(3, 5)