def add(a, c):
    result = a + c
    if a > c:
        return result
    else:
        return c - a

def loop_example(x):
    total = 0
    for i in range(x):
        total += i
    while total < 100:
        total += 1
    return total

y = add(3, 5)